# Influence of University teachers’ job satisfaction on subjective well-being and job performance

Dr S Pavan Kumar

Associate Professor, School of Management   
National Institute of Technology Karnataka (NITK), Surathkal   
pavankumar@nitk.edu.in

Abstract - Research previously found a direct relationship between job satisfaction (JS) and employee job performance (JP). However, the literature reveals that the influence of intervening variables such as employee subjective well-being (SWB) might have an impact on job satisfaction and job performance relationship. Broaden-and-build model as the theoretical base, a conceptual model was developed where SWB moderates the relation between JS and JP. One unique addition of the study is the introduction of Necessary Condition Analysis (NCA). Three hundred and ninety-five teachers working for private engineering institutions participated in the study. Results revealed that teachers job satisfaction predicts job performance directly and also through subjective well-being. It show that more satisfied teachers are more likely to show increased job performance when they are experiencing low level and a moderate level of subjective wellbeing. NCA scatterplots and bottleneck analysis prove the necessity of JS and SWB to predict JP.

Keywords - Job satisfaction; subjective well-being; job performance and necessary condition analysis.

JEET Category - Research

## I. INTRODUCTION

T<sub>he</sub> <sub>business</sub> <sub>environment</sub> <sub>across</sub> <sub>the</sub> <sub>globe</sub> <sub>has</sub> <sub>become</sub> dynamic like never before. Fast-growing, unpredictable, cut-throat competition are a few of its hallmarks. It has become inevitable for organizations to search for employees who can exhibit proactive behaviour under such unique circumstances. These proactive employees are now a lifeline for many organizations; it is particularly true, referring to knowledge-intensive sectors, which includes educational institutions as well. To meet its end, if organizations continue to keep track only on the production side of the organization while ignoring individual requirements might push employees in the doldrums. Such a situation can have a significant impact on the emotions of the employees. Consistent with this intuition, the overall balance of employees' positive and negative emotions can contribute to their well-being (Diener et al., 1991). Many different terms are used in the psychology literature to describe well-being. However, “Psychological well-being"

is the complete term. It includes "Subjective well-being", which is how individuals evaluate or appraise their own lives. Behavioral scientists have derived 'subjective wellbeing' (SWB) from the factors that made employees experience their lives in positive versus negative ways. Scholars in the field of SWB reiterated that the employees' evaluations of their lives are essential phenomena and should be considered as an aspect of a good life. They also had indicated that SWB is beneficial for demonstrating citizenship behaviour, work performance, and resilience (Diener et al., 2018). Work performance is the variable which has received wide attention in the management research literature, and it is the need of the hour for any organization in this competitive world.

An educational set-up, such as an educational institution or university, can be classified as an organization established to attain specific goals defined by its boundaries (Thomas, 2004). Like any other organization, educational institutions or universities are unique in their identity, the rules by which they function, and forms of interaction they display and decision-making processes (Kumar, 2011). Hence, educational institutions/Universities offer us to study them as organizations. The success of any institution/University to a greater extent depends on the quality of the teacher and his/her teaching abilities. However, there is no doubt, infrastructure facilities will definitely help in the teaching and learning process, but a teachers’ role is more prominent. Many scholars had already proved the connection between job satisfaction and the teachers' job performance. What is needed more is the role of intervening variables that can explain the teaches job satisfaction and job performance relationship to a greater extent. The intervening variables could be such as teachers’ well-being or head of the institutions' support etc. Basically, those variables which are part of his/her work environment. This study is designed to verify the role of teachers’ subjective well-being on the relationship between teachers’ job satisfaction and job performance. One more addition of this study is Necessary Condition Analysis (NCA). The procedure and the utility of NCA are discussed graphically in the methodology section. The subsequent sections of the papers will give us the chronology of the research process followed.

## II. LITERATURE REVIEW

Lyubomirsky et al. (2005) have found that the employees who experience high in positive feelings and job satisfaction exhibit higher performance than their unhappy colleagues/co-workers. Hence, job attitudes have importance beyond consideration, and the most widely investigated job attitude is job satisfaction. Perhaps it is the most extensively researched topic in organizational psychology research domain (Judge & Church, 2000). Job satisfaction occupies a prominent position in many theories and models of individual attitudes and behaviours, and this is because job satisfaction research has practical applications for the enhancement of own lives as well as organizational effectiveness. (Eid & Larsen, 2008). A satisfied employee with his/her overall job situation, accompanied by a high level of positive feelings and happiness could be a game-changer in terms of overall organizational effectiveness and individual performance.

Pfeffer and Jeffrey (1998) have expressed their faith that people-centred strategies would result in better performance of the employees and make a profit for the organizations. People-centred strategies focus on employee-friendly policies such as employment security, self-managed teams, and decentralization of decision making etc. they are a few feel-good factors among the employees. Thus, feel-good factors, in turn, play a catalyst role in elevating happiness, pleasure, or satisfaction that employees take from their work environment. According to Güney (2011, p. 12), job satisfaction is "the happiness and peacefulness employees feel when what they gain at the workplace meets their material and spiritual needs". For teachers, job satisfaction means pleasure, enjoyment, satisfaction, happiness and positive feelings towards his/her work (Uzun, & Ozdem, 2017).

Literature shows that there exists a positive relationship between job satisfaction and job performance (Demirhan et al., 2014). The job performance is a concept that expresses to what degree a goal has been achieved at a job. Job performance means work accomplishment or the degree of success demonstrated in any job (Demirtaş & Güneş, 2002). The teacher's job performance corresponds to how successfully a teacher fulfils assigned duties and responsibilities.

An ample number of previous researches have indicated that job satisfaction is strongly and consistently related to subjective well-being. Researchers have postulated that the possible reason for such a relationship to spillover effect, wherein job experiences spill over onto life experiences, and vice versa (Eid & Larsen, 2008). Consistent with the spillover model, literature indicated that job and life satisfaction are moderately correlated (Tait et al., 1989). The subjective well-being (SWB) focuses on the degree to which an individual teacher judges, the overall quality of his or her life as a whole in a pleasant way (Kumar, 2020). Presence of positive emotional states among the teachers could accentuate worker performance and the quality of life (i.e., the happier the teachers are, the more productive they are). Thus, the ability to promote well-being rather than engender strains and mental illness is of considerable benefit not only to employees but also to the employer's bottom line (Russell, 2008). Because subjective well-being is related to performance, it is natural that the administrators of the educational institutions would want to strengthen the feelings of subjective well-being among their teachers. With this intuition in mind, the current study aims to investigate the impact of teachers’ job satisfaction on job performance. To understand the relationship entirely, the role of intervening variables for this relationship must be followed. Teachers’ subjective well-being is one such potential variable which can moderate the relationship between job satisfaction and job performance. A clue can be taken from the work done by Write and Cropanzano (2000), they have found the main effect association among job satisfaction, employee well-being and job performance. Based on such findings, Fredrickson and Losada (2005), in their broaden-and-build model suggested that satisfied and well-being employees are more likely to demonstrate better job performance when compared to less happy and less well-being employees. Fredrickson's model suggests that positive feelings, such as employee subjective well-being, will anyway have a positive influence on employee job performance, but can also provide theoretical support for the moderating effect of SWB (Kumar, 2017). Based on the above theoretical arguments, the following hypotheses were formulated:

H<sub>1</sub>: There is a positive relationship between job satisfaction and job performance.

H<sub>2</sub>: There is a positive relationship between job satisfaction and subjective well-being.

H<sub>3</sub>: There is a positive relationship between Subjective well-being and job performance.

H<sub>4</sub>: Subjective well-being will moderate the relationship between job satisfaction and job performance.

![](images/915b2eb55f4e693f6da45b87fe921741593c3aee1962f711983f705012b3be6e.jpg)  
Fig. 1 Conceptual Model. Note: H<sub>1</sub> to H<sub>4</sub> are the proposed hypotheses, + sign indicates a positive relationship, Arrow line indicates the direction of a causal relationship, Dash line indicates the moderating relationship, Rectangle shape represents the latent construct.

## III. METHODOLOGY

The research setting for this empirical study is private engineering institutions located in the states of Telangana and Andhra Pradesh. The framework is all about exploring the direct impact of teachers’ job satisfaction and subjective well-being on job performance and subjective well-being role as a moderator between job satisfaction and job performance. The model was developed on the premise that happy teachers are productive teachers. A teacher who is satisfied with overall life situations is expected to contribute to teachers’ job satisfaction and job performance

relationship. The current model has its connection with the mushrooming of private engineering institutions in the last decade in the twin states. Umashankar and Dutta (2007) have mentioned in their findings that higher education is expanding, but mostly in an unplanned manner, without even minimum levels of checks and balances. If these private engineering institutions have to attain success, they need to stand tall among many other top performing engineering institutions of the country. Hence it becomes essential to understand and identify the process by which teachers’ job performance can be made useful.

The study is based on a sample of 395 teachers working for various private engineering institutions of Telangana and Andhra Pradesh states of India. Random sampling method was adopted to collect the data. Sufficient care was taken to have sample representation from all the regions of the two states. Female respondents were 37.5 per cent and male teachers were 62.5 per cent. The average age of the respondents was 35.5 years.

## A. Conceptualization and Operationalization of Variables

Job satisfaction was conceptualized as the extent of the positive affective orientation towards the job. Job satisfaction was measured by a scale developed by Jenkins, Nadler, Lawler, and Cammann (1975). The scale consisted of three items. Sample item included is, ‘I get a feeling of personal satisfaction in doing my job’. Subjective wellbeing scale was about the overall judgment of life to measure the concept of life satisfaction. Subjective wellbeing was measured by a five-item scale developed by Diener, Emmons, Larsen, and Griffin (1985). A sample item is, ‘In most ways, my life is close to my ideal’. The job performance questionnaire was validated in the context of the specific responsibility of employees during their work to evaluate the formal performance requirement for their job. To measure teachers’ job performance scale developed by Lynch, Eisenberger, and Armeli (1999) was used. This scale comprised nine items. A sample item included was, ‘Employees perform tasks that are expected of them’. Response categories against each of the question for all the scales included in the study were on a five-point Likert level ranging from strongly disagree=1 to strongly agree=5.

## IV. FINDINGS AND RESULTS

Data were subjected for screening to check missing values, unengaged responses, potential outliers, skewness, and kurtosis before proceeding for further analysis. Missing values for all the study variables were far less than five per cent, and hence series mean substitution method was adopted (Hair et al., 1998). Unengaged responses were deleted, there were no outliers, and the data were nonskewed and non-kurtotic. Descriptive statistics were performed by using SPSS 20.0, causal inferences and moderation analysis were tested using SmartPLS 3.0. It is a variance-based structural equation modelling tool used to model latent variables and relationships between them (Henseler, 2017).

TABLE 1  
Descriptive statistics such as mean and standard deviation, Reliability coefficients, Correlations among latent variables, Average variance extracted (AVEs) (diagonal values in italics) and Square root of AVEs (values in parenthesis) are shown.
<table><tr><td>Variable</td><td>Mean</td><td>Standard Deviation (SD)</td><td>Reliability (Cronbach&#x27;s Alpha)</td><td>Composite Reliability</td><td>JS</td><td>JP</td><td>SWB</td></tr><tr><td>JS</td><td>3.99</td><td>.98</td><td>.88</td><td>.93</td><td>.81(.90)</td><td></td><td></td></tr><tr><td>JP</td><td>3.95</td><td>.85</td><td>.90</td><td>.92</td><td>.71**</td><td>.57(.75)</td><td></td></tr><tr><td>SWB</td><td>3.77</td><td>.95</td><td>.87</td><td>.91</td><td>.68**</td><td>.73**</td><td>.66(.81)</td></tr></table>

Note: All correlations are significant at \*\* p<.001; JS − Job Satisfaction, JP – Job Performance, SWB – Subjective Well-being.

Reliability and validity are two important tests which ensure psychometric properties of the scales. Reliability is the accuracy in measurements when the measurements are repeated. Usually, reliability is measured using Cronbach’s Alpha and Composite reliability. Measurements having realibility of .7 and above is considered to be acceptable (Fornell & Larcker, 1981). Validity refers to the capability to measure the right concept. Two important validity forms of validity are convergent and discriminant. Convergent validity refers to an indicator of a specific construct that converges towards a large portion of the variance that is in common. One way to verify this is to check AVE values higher than .5 (Hair et al., 1998). In this present study, AVE values were ranging from .57 to .81, and hence convergent validity is achieved. Discriminant validity refers to indicators within a construct are strongly associated with each other, but are distinct from other construct indicators. To determine discriminant validity, square roots of AVEs should be higher than the correlations between constructs. In this study, the square root of AVE values was ranging from .75 to .90 and was significantly higher than the correlations between constructs and hence, discriminant validity is also achieved (see table I). Apart from the validity and reliability, one more important concept to check is the multi-collinearity problem. High collinearity between two or more than two indicators can bias the results. Hence, indicators belonging to each construct were tested for such problems. Variance Inflation Factor (VIF) of 3.3 or less suggests the absence of multi-collinearity and

Journal of Engineering Education Transformations,

Volume No 35, January 2022, Special issue, eISSN 2394-1707

high inter-associations among variables (Kock & Lynn, 2012). For the present study, it was ranging from 1.66 - 2.98.

## V. NECESSARY CONDITION ANALYSIS

The present study uses Necessary Condition Analysis (NCA) to verify whether teachers job satisfaction and teachers’ subjective well-being are the necessary to predict teachers job performance. Researchers are of the opinion that the presence of necessary conditions may not ensure the outcome; however, without necessary conditions, the outcome does not exist (Dul, 2018). Hence, this study stands unique by performing NCA. Data was collected from 395 teachers' working for private engineering institutions of the states of Telangana and Andhra Pradesh. NCA scatterplots, statistics, and bottleneck analysis had proven the necessity of one relationship for another. In NCA plot, the empty zone without observations is separated from the zone with observations by a straight ceiling line known as cr-fdh (ceiling regression with free disposable hull). The step ceiling line is ce-fdh (ceiling an envelope with free disposable hull). However, only cr-fdh values are considered for the study as they are less sensitive to outliers and measurement errors compared to ce-fdh values (Dul, 2018).

All three figures, 2, 3, and 4, have a space in the top left corner. This suggests the presence of necessary (but not sufficient) condition, that is, (Job satisfaction) JS and (Subjective well-being) SWB are necessary to determine Job performance (JP) (Dul, 2018). In table II, the effect size is .114 and .16 between JS and JP and SWB and JP, respectively. This means JS and SWB have a medium effect on JP (0<d<0.1 is a small effect, 0.1 to 0.3 is a medium effect and 0.3<d<0.5 is a large effect). Accuracy is well above 95%, which indicates that JS and SWB can predict JP. Higher outcome inefficiency (49.866%) renders the prediction of JP by JS less likely compared to SWB (25.254%).

TABLE II  
NCA statistics for cr-fdh to predict JP
<table><tr><td>Parameters</td><td>JS</td><td>SWB</td></tr><tr><td>Ceiling zone</td><td>16.42</td><td>23.105</td></tr><tr><td>Effect size</td><td>.114</td><td>.160</td></tr><tr><td>Accuracy</td><td>98.2%</td><td>97.2</td></tr><tr><td>Condition inefficiency</td><td>54.512</td><td>57.067</td></tr><tr><td>Outcome inefficiency</td><td>49.866</td><td>25.254</td></tr></table>

Note: JS = Job satisfaction, SWB = Subjective well-being, and JP = Job performance

![](images/24b00194b2c516f217a7e0fb00e888acc956065c7e95d3a098dd34463a34b41b.jpg)  
Fig. 2 NCA Plot - Job Satisfaction and Job Performance. Note: X-axis represents Job satisfaction and Y-axis represents Job performance.

![](images/ad16b46ff9579e95db695a6f4ef99a67fc1a0f5b3d64ca588248eb4c379567b9.jpg)  
Fig. 3 NCA Plot - Subjective well-being and Job Performance. Note: Xaxis represents Subjective well-being and Y-axis represents Job performance

![](images/095ef174f6cb8b5ccee4a30d419d9918d35abbc11d0e6cfc2e6be5fad5fe0e98.jpg)  
Fig. 4 NCA Plot - Subjective well-being and Job Performance. Note: Xaxis represents Job satisfaction and Y-axis represents Subjective wellbeing

TABLE III  
Bottleneck table for cr\_fdh between JS (1), SWB (2) and JS (Y)
<table><tr><td>Y</td><td>1</td><td>2</td></tr><tr><td>0</td><td>NN</td><td>NN</td></tr><tr><td>10</td><td>NN</td><td>NN</td></tr><tr><td>20</td><td>NN</td><td>NN</td></tr><tr><td>30</td><td>NN</td><td>2.7</td></tr><tr><td>40</td><td>NN</td><td>8.5</td></tr><tr><td>50</td><td>0.1</td><td>14.2</td></tr><tr><td>60</td><td>9.2</td><td>20</td></tr><tr><td>70</td><td>18.3</td><td>25.7</td></tr><tr><td>80</td><td>27.3</td><td>31.4</td></tr><tr><td>90</td><td>36.4</td><td>37.2</td></tr><tr><td>100</td><td>45.5</td><td>42.9</td></tr></table>

Note: JS = Job satisfaction, SWB = Subjective well-being, and JP = Job performance

Bottleneck table III usually shows the percentage of independent variables that are necessary for dependent variables. According to the cr-fdh curve, for a job performance level of 30%, Job Satisfaction is not necessary (NN), and only 2.7% of Subjective well-being is necessary. Usually, “when dependent variable increases from 0 to 100%, more independent variables become necessary and required levels of independent variables become higher” (Dul, 2018, p.14). Hence, for a JP level of 90%, 36.4% of JS and 37.2% of SWB is necessary. For a JP level of 100%, 45.5% of JS and 42.9% of SWB is necessary. It is evident from the results that both JS and SWB are necessary to predict JP, let us move on to the model results.

![](images/ff1c12d6bfb3fde1269ed2a264f141432b7d5ca829ec8d0462a6e511fc126a9a.jpg)  
Fig. 5 Outer Loadings of Indicators (Factor loadings), Inner values (β path coefficients), and R<sup>2</sup> values are shown. All the loadings are significant at P<.001, whereas β path coefficient of all causal relationship is significant at p<.05. All the item loadings that were considered for the present study were measured above .50.

![](images/8c316de61c2b39eff0f0da092e3246b8945e89b2ddca2a50da3712e1f58226f4.jpg)  
Fig. 6 t-statistics is shown for all the indicator variables and for the β path coefficients of the model. Note: Significance of each parameter can be determined using t-values.

## VI. MODEL QUALITY

A model quality can be assessed based on the ability of its exogenous constructs to predict the endogenous constructs. $\mathtt { R } ^ { 2 }$ Coefficient is a measure of the model's predictive accuracy. $\mathtt { R } ^ { 2 }$ value ranges from 0 to 1, where 1 represents complete predictive accuracy. $\mathtt { R } ^ { 2 }$ with 0.75, 0.50,

0.25, respectively, describing substantial, moderate, or weak levels of predictive accuracy (Hair et al., 2011). For the present model, the $\mathtt { R } ^ { 2 }$ value is .732, which gives an idea that the exogenous constructs of the model have achieved almost substantial prediction accuracy. Hence, the inner model is declared to be fit and can also be used for hypothesis testing. However, $\mathtt { R } ^ { 2 }$ will increase even if a nonsignificant and slightly correlated construct is added to the model. Hence, Hair Jr, Sarstedt, Hopkins, and Kuppelwieser, (2014) suggests considering adjusted $\mathrm { R } ^ { 2 } { \mathrm { ; } }$ , as it takes care of increased model complexity by reducing the (adjusted) $\mathsf { R } ^ { 2 }$ . For the present model, even the adjusted $\mathtt { R } ^ { 2 }$ value is healthy at .73. However, according to Hair, et al., (2017) criteria for evaluating the goodness-of-fit of a PLS-SEM model includes fit indices like Standardized Root Mean Square Residual (SRMR) and Normed Fit-Indices (NFI). SRMR for the present model is 0.06 (less than .08, which is an ideal value), and NFI is found to be 0.85, which is an acceptable value. This suggests that this model has a sound fit-indices. Figure 5 and 6 shows the results of $\beta$ coefficients for each causal path, and they represent the standardized regression path coefficients associated with statistically significant effects.

TABLE IV  
Summary of hypothesized causal relationship results
<table><tr><td>Sl. No. of Hypothesis</td><td>Hypothesized Relations</td><td>Path Coefficients (β)</td><td>t-statistic</td><td>Result</td></tr><tr><td> $\mathrm { H } _ { 1 }$ </td><td> $\mathrm { J S }  \mathrm { J P }$ </td><td> $. 1 2 7 ^ { * }$ </td><td>3.02</td><td>Accepted</td></tr><tr><td> $\mathrm { H } _ { 2 }$ </td><td> $\mathrm { J S }  \mathrm { S W P }$ </td><td> $. 6 8 1 ^ { * * }$ </td><td>16.48</td><td>Accepted</td></tr><tr><td> $\mathrm { H } _ { 3 }$ </td><td> $\mathrm { S W B }  \mathrm { J S }$ </td><td> $. 2 8 7 ^ { * * }$ </td><td>5.28</td><td>Accepted</td></tr><tr><td> $\mathrm { H _ { 4 } }$ </td><td> $\mathrm { J S x S W B }  \mathrm { J P }$ </td><td> $- . 3 8 0 ^ { * * }$ </td><td>11.88</td><td>Accepted</td></tr></table>

Note: \*\* Significant at $\mathrm { p } { < } . 0 0 1 , \ ^ { \ast }$ significant at p<.05 level; JS − Job Satisfaction, JP – Job Performance, SWB – Subjective well-being

It can be seen from table $\mathrm { I V } ,$ that teachers job satisfaction has a significant positive impact on teachers’ job performance, and teachers’ subjective well-being with (β=.127, p<.05, t=3.02), and (β=.681, p<.001, t=16.48) respectively. Hence, hypotheses H<sub>1</sub> and $\mathrm { H } _ { 2 }$ were accepted. Similarly, teachers’ subjective well-being has a significant positive impact on teachers’ job satisfaction with (β=.287, p<.001, t=5.28); hence H<sub>3</sub> was also accepted.

According to Falk and Miller (1992), the strength of each path of the model and the $\mathtt { R } ^ { 2 }$ coefficients of endogenous variables should be minimum of .1. Figure 5 shows that the $\mathtt { R } ^ { 2 }$ coefficient of job performance (JP), and subjective well-being (SWB) were .732 and .464, respectively. $\mathtt { R } ^ { 2 }$ of .732 for endogenous job performance construct essentially means a good amount of variance is explained by variables such as teachers job satisfaction (JS) and teachers’ subjective well-being put together. Variance (R<sup>2</sup>) of $\mathrm { J P }$ is .732, meaning that JS and also SWB moderation can explain 73.2% variance in JP, while remaining 26.8% is explained by other variable(s), basically beyond the scope of the model. The t-statistics of significant paths were above 1.96, as mentioned in table 4. Any value

Journal of Engineering Education Transformations,

Volume No 35, January 2022, Special issue, eISSN 23 for t-statistic above 1.96 is considered to be having significant level (Hair et al., 2016). Results of the hypotheses test on direct effect in Table 4 indicates that teachers job satisfaction has a direct and significant effect on both teachers’ subjective well-being and job performance. Similarly, teachers’ subjective well-being has positive and significant on teachers’ job performance. Hence, the structural model is validated.

## VII. THE MODERATING EFFECT OF SWB ON THE RELATIONSHIP BETWEEN JS AND JP

A mediation or a moderation effect test is possible only if the direct effect between the independent and the dependent variable is significant (Hair et al., 2014). The direct effects for the present study were found to be significant, and therefore, the hypothesis test on the moderation effect of SWB on the relationship between JS and JP was conducted. The results demonstrated that SWB is acting as a moderator between JS and JP relationship with (β= -.380, p<.001, t=11.88), whereas the result of the direct path between JS and JP is (β=.127, p<.05, t=3.02) (See figures 5 & 6).

![](images/128c2bd740ae5f5c8d6b7bf4cfb37766c3195faa9d1e891781f0e8f48199a4fd.jpg)  
Fig. 7 Showing the moderating role of subjective well-being between the job satisfaction and job performance relationship. Note: Independent variable = Job satisfaction, Moderator = Subjective well-being (at SD = - 1, 0, and +1), Dependent variable = Job performance. Top line shows subjective well-being, standard deviation (SD) at +1, middle line shows subjective well-being, SD at mean, and bottom line shows subjective wellbeing, SD at -1.

## VIII. DISCUSSION

We can observe significant positive correlation values (see table 1) between job satisfaction, subjective well-being and job performance. This gives us an indication to proceed ahead with verifying the proposed positive causal relationships of the model (see Fig.1). However, we have to understand that the presence of a significant positive correlation between constructs will not guarantee causation to happen. Judge, Thoresen, Bono, and Patton (2001) research on the relationship between job satisfaction and job performance is among the extensively referred topic in organizational psychology. In specific ways, the results obtained in this study are consistent with Judge et al.'s (2001) findings, which says that job satisfaction predicts job performance. Result obtained in this study is compatible with Wright Thomas and Cropanzano Russell and Bonett Douglas (2007) finding, which says that teachers' wellbeing moderates’ relationship between teachers' job satisfaction and teachers' job performance. We can observe that teachers' job satisfaction and teachers' subjective wellbeing together proved to be a strong predictor when compared to teachers' job satisfaction all alone predicting teachers' job performance.

However, Wright et al. study found that job satisfaction does predict job performance, assuming the employee also has a high level of personal well-being (PWB). On the contrary note, job satisfaction is not a significant predictor of job performance among employees with low levels of psychological well-being. (It is sometimes called as personal well-being or subjective well-being, see Diener, 1984, 1994). However, in the present study, teachers job satisfaction predicts job performance directly as well as along with the teachers' subjective well-being such that more satisfied teachers are more likely to show increased job performance when they are experiencing low level and moderate level of subjective well-being. Further, teachers with more satisfaction are more likely to demonstrate decreased job satisfaction when they are experiencing high subjective well-being. The findings are a bit surprising. This might be because of the circumstances that prevail in higher educational Institutions/Universities. In Indian higher educational institutions, the teachers do not have many hierarchies to attain before their superannuation.

The main goal of the majority of the teachers working in the university system is to get promoted to professor position and settle down. The salary drawn by a professor and privileges he receives is at par with standards of the industry after implementation of the seventh pay scale by the Government of India. They are expected to have all the necessary comforts they can think about. Once a teacher attains the professor level, after successfully completing their duty as an assistant professor and associate professor positions, they start realizing that they have reached the peak of their career and there is no more scope for further improvement in the career position. Probably, this notion of a sense of satisfaction and well-being is keeping them away from optimal performance. Furthermore, the results related to the relationship between job satisfaction and subjective well-being is in-line with the findings of Judge, Klinger, Simon, and Yang, (2008), job satisfaction emerges as a strongest subjective well-being. Job being a important part of one's life, the positive relationship between teachers job satisfaction and well-being makes sense.

## IX. IMPLICATION

The findings of the study can be made used by both teachers for their betterment and also by the university authority to advocate good management practices. People at the helm of managing the responsibilities and decision making may want to pay closer attention to the well-being of their teachers. This is because the success of an educational institution depends heavily on the quality of the teachers and their teaching strategies when compared to that of having state-of-the-art infrastructure facilities. After the arrival of foreign universities and top quality private deemed to be universities in Indian, the mediocre higher educational institutions are rapidly losing their competitive position, and to a few institutions, existence itself has become a challenge. While teachers SWB has its relevance for teachers' job performance, the decision-makers of the institutions/universities should provide ample opportunity to teachers to enhance SWB through number of trainingbased interventions, which can proactively self-monitor and enhance teachers' positive emotions and discourage their negative emotions at workplace. Sufficient attention should be paid to a category of teachers who are either very close to their superannuation or the one who has already attained the highest academic position in the university system and enjoying all the possible privileges they are entitled to. Essentially, those teachers who are running high on positive emotions and who feel very happy with their overall life situation should be made realize the importance of their continuous contribution to the growth and development of the Institution. They must be made aware of the fact that their contribution is needed not just for sustenance, but also to bring fresh success and glory to the Institution. This discussion emphasizes the importance of management interventions, as they can benefit both the individual teacher through enhanced SWB, as well as the Institution through increased job performance. Especially, intervention strategies designed to make aware about their strengths (Peterson & Seligman, 2004) such as love of learning, authenticity, and hope in new and novel ways of executing the teaching job etc.

## X. LIMITATIONS AND RECOMMENDATIONS

As with any other research study, the present study also has certain limitations. The sample chosen for the research work includes teaching faculty working for private engineering institutions situated the in Telangana and Andhra Pradesh states of India. Hence, the findings of the study are to be considered with caution. The present work was carried out on cross-sectional data; the results could have been better when data is analysed, drawn from two different periods from the same sample. Future researchers may consider alternate models by interchanging the position of job performance and subjective well-being, and also considering a few new constructs which are related to working condition in a university environment in place of subjective well-being. The new finding might emerge by replicating the study among teachers' working for the Government-funded engineering institutions of India.

## XI. CONCLUSION

This empirical paper provides enough evidence supporting the incorporation of both teachers' subjective well-being (SWB) and teachers' job satisfaction in consideration of the happy/productive worker scholarly work. Using the broaden-and-build model as the theoretical base, the scholar had found that SWB moderates the relation between teachers' job satisfaction (JS) and teachers' job performance (JP). Although there exists a significant direct relationship between JP and JS, Job performance was highest when teachers reported low to average scores on SWB. Further research is needed to examine alternate models more closely. One may also consider different work environment-related variables such as the head of the institutions support as a moderator. These could be beneficial in predicting teachers' attitudinal and behavioural aspects across differing job situations. One other important contribution of the papers is necessary to condition analysis, which made it clear that teachers job satisfaction and teachers subjective well-being are the necessary conditions to predict teachers job performance.

## REFERENCES

Aydemir, P. & Erdoğan, E. (2013) İş görenlerin ücret tatmini, iş tatmini ve performans algısı, Kamu-İş, 13(2),127-153.

Demirhan, Y., Kula, S. & Karagöz, G. (2014) The effect of job satisfaction and supervisor support on performance: The example of special operations police unit of Diyarbakır province, Suleyman Demirel University Faculty of Economics and Administrative Sciences Journal, 19(1), 285-297.

Demirtaş, H. & Güneş, H. (2002), Eğitim Yönetimi ve Denetimi Sözlüğü, Anı Yayıncılık, Ankara.

Diener, E., Sandvik, E. & Pavot, W. (1991), Happiness is the frequency, not the intensity, of positive versus negative affect, in Subjective well-being: An interdisciplinary perspective, Pergamon Press, United Kingdom pp. 119-139.

Diener, E. (1984) Subjective well-being, Psychological Bulletin, 95, 542–575.

Diener, E. (1994) Assessing subjective well-being: Progress and opportunities, Social Indicators Research, 31, 103–157.

Diener, E., Emmons, R. A., Larsen, R. J. & Griffin, S. (1985) The satisfaction with life scale, Journal of Personality Assessment, 49, 71-75.

Diener, E., Oishi, S. & Tay, L. (2018) Advances in subjective well-being research, Nature Human Behaviour, 2(4), 253 - 260.

Dul, J. (2018) Necessary condition analysis (NCA) with R (version 3.0.1): A quick start guide, Organizational Research Methods, 19(1), 10-52.

Eid, M. & Larsen, R. J. (2008), The science of subjective well-being, Guilford Press.

Falk, R. F. & Miller, N. B. (1992), A primer for soft modelling, University of Akron Press.

Fornell, C.G. & Larcker, D.F. (1981) Evaluating structural equation models with unobservable variables and measurement error, Journal of Marketing Research, 18(1), 39-50.

Fredrickson, B. L. & Losada, M. F. (2005) Positive affect and the complex dynamics of human flourishing, American psychologist, 60(7), 678.

Güney S (2011), Örgütsel davranış, Nobel Yayın Dağıtım, Ankara.

Hair Jr., J. F., Hult, G. T. M., Ringle, C. & Sarstedt, M. (2016), A primer on partial least squares

Journal of Engineering Education Transformations,

Volume No 35, January 2022, Special issue, eISSN 2394-17 structural equation modeling (PLS-SEM), Sage publications.

Hair, J. F., Anderson, R. E., Tatham, R. L., William, C. & Black (1998), Multivariate data analysis, 5, 87- 135.

Hair, J. F., Hult, G. T. M., Ringle, C. M., & Sarstedt, M. (2017), A Primer on Partial Least Squares Structural Equation Modeling (PLS-SEM), 2nd edition, Sage, Thousand Oaks.

Hair, J.F., Hult, G.T.M., Ringle, C.M. & Sarstedt, M. (2014), A Primer on Partial Least Squares Structural Equation Modeling, Sage, Thousand Oaks, CA.

Hair, J.F., Ringle, C.M. & Sarstedt, M. (2011) PLS-SEM: indeed a silver bullet, Journal of Marketing Theory and Practice, 19(2), 139-151.

Henseler, J. (2017) Bridging design and behavioral research with variance-based structural equation modelling, Journal of advertising, 46(1), 178-192.

Jenkins, G. D., Nadler, D. A., Lawler, E. E. & Cammann, C. (1975) Standardized observations: An approach to measuring the nature of jobs, Journal of Applied Psychology, 60, 171-181.

Judge, T. A. & Church, A. H. (2000), Subjective well-being: Research and practice, in Industrial and organizational psychology: Linking theory with practice, Blackwell, Oxford, pp. 166–198.

Judge, T. A., Klinger, R., Simon, L. S. & Yang, I. W. F. (2008) The contributions of personality to organizational behavior and psychology: Findings, criticisms, and future research directions. Social and Personality Psychology Compass, 2(5), 1982- 2000.

Judge, T. A., Thoresen, C. J., Bono, J. E. & Patton, G. K. (2001) The job satisfaction-job performance relationship: A qualitative and quantitative review, Psychological Bulletin, 127, 376–407.

Kock, N. & Lynn, G. (2012) Lateral collinearity and misleading results in variance-based SEM: An illustration and recommendations, Journal of the Association for Information Systems, 13(7).

Kumar S. P. (2011), Impact of teachers’ participation in decision making and commitment on organizational citizenship behaviour, Unpublished Ph.D. thesis, Indian Institute of Technology Kharagpur, Kharagpur, West Bengal, India.

Kumar, S. P. (2017) Subjective Well-being as a Moderator between Job Satisfaction and Job Performance: A Conceptual Framework, International Journal of Economic Research, 14(17), 429-435.

Kumar, S. P. (2020) Workplace Spirituality as an Antecedent of University Teachers' Subjective Well-Being: Mediating Role of Subjective wellbeing and Job Performance, Journal of Engineering Education Transformations, 33, 137- 146.

Lynch, P. D., Eisenberger, R. & Armeli, S. (1999) Perceived organizational support: Inferior versus

superior performance by wary employees, Journal of applied psychology, 84(4), 467.

Lyubomirsky, S., King, L. A. & Diener, E. (2005) The benefits of frequent positive affect: Does happiness lead to success? Psychological bulletin, 131(6), 803–855.

Peterson, C. & Seligman, M. E. P. (2004), Character strengths and virtues: A handbook and classification, American Psychological Association, Washington, DC.

Pfeffer, J. & Jeffrey, P. (1998), The human equation: Building profits by putting people first, Harvard Business Press.

Russell, J. E. (2008) Promoting subjective well-being at work, Journal of career assessment, 16(1), 117- 131.

Tait, M., Padgett, M. Y. & Baldwin, T. T. (1989) Job and life satisfaction: A reevaluation of the strength of the relationship and gender effects as a function of the date of the study, Journal of applied psychology, 74(3), 502.

Thomas, C. (2004), Organizational commitment of teachers of higher education, Centre for publications, Christ College, Bangalore.

Umashankar, V. & Dutta, K. (2007) Balanced scorecards in managing higher education institutions: An Indian perspective, International Journal of Educational Management, 21, 54-67.

Uzun, T. & Ozdem, G. (2017) The Mediating Role of Subjective well-being on the Relationship between Teachers' Perceptions of Supervisor Support and Job Performances, International Journal of Educational Administration and Policy Studies, 9(7), 84-90.

Wright, T. A., Cropanzano, R. & Bonett, D. G. (2007) The moderating role of employee positive well-being on the relation between job satisfaction and job performance, Journal of occupational health psychology, 12(2), 93-104.