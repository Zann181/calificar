![](images/2628a8100b5fa1f483fbd82023d82664d1ac73d9b082f7b964382c57a16a826a.jpg)

# Efect of Perception of Organizational Support on Organizational Citizenship Behaviour: The Mediating Role of Employee Happiness

Shiwani Singh<sup>1</sup>  · Taruna<sup>1</sup>  · Jyoti Singh Bharti<sup>1</sup>

Accepted: 9 May 2023

© The Author(s), under exclusive licence to Springer Science+Business Media, LLC, part of Springer Nature 2023

## Abstract

This study is focused on an empirical investigation of the relationship between organizational support perception (POS) and organizational citizenship behaviour (OCB), and also to find out the efect of employee happiness (EH) as a mediating variable on this relationship. The data was obtained from 219 retail sector employees through the survey questionnaire. The data was analyzed with the use of structural equation modeling (SEM) carried out in AMOS 26 to test the hypotheses. The study’s findings pointed out that POS predicts OCB both directly and indirectly through the mediating role of EH. The results of this study suggest that management should strive to improve the factors that influence employees’ POS to raise EH at work and OCB. Human resource practices such as flexible work arrangements, training and development opportunities, wellness programs, workplace justice, etc. can contribute to strengthening the relationship between the organization and its employees, thereby enhancing the perception of organizational support.

Keywords Perceived organizational support · Employee happiness · Organizational citizenship behaviour · Retail sector

## Introduction

In the prevailing dynamic and competitive environment, it is crucial for all organizations that their entire workforce exhibit extra-role behaviour (Grego-Planer, 2019). The term extra-role behaviour was coined by Organ in the 1980s which is also called organizational citizenship behaviour (OCB). OCB can be explained as behaviour that is crucial for an organization’s eficient functioning but does not fall under a specific job responsibility. Without any expectation of compensation or credit, employees take on extra responsibilities voluntarily with the sole intent of assisting their coworkers and the company (Smith et al., 1983). The success of an organization is significantly impacted by an employee’s selfless eforts for the betterment of the organization. An organization’s competitive advantage is generated from its personnel’s positive behavior and endeavors that go beyond their mandated or contractual responsibilities (Ranjhan & Mallick, 2018). Therefore, organizations must identify the variables that could have an impact on OCB. Organizations should be aware of the drivers of OCB in advance and strive to enhance these drivers so that employees will be encouraged to involve in extra-role behaviour.

Perceived organizational support (POS) tends to drive organizational citizenship behaviour in the workplace. POS promotes extra-role behaviour that benefits the entire organization, such as advocating for the organization’s goods & services and making insightful suggestions for any problem or projects which ultimately improves the operation of the company (Kaufman et  al., 2001). The findings of past studies indicated that POS has been positively associated with job performance, affective commitment, employee engagement, job satisfaction, and organizational citizenship behaviour (Alshaabani et  al., 2021; Erdogan & Enders, 2007; Piercy et  al., 2006). Furthermore, social exchange theory (SET) also stresses that POS invokes the reciprocity principle, as supported employees build a positive image of the organization and actively contribute to the attainment of organizational goals by voluntarily participating in extra-role behaviours.

Enhancing employee happiness (EH) at work is very crucial for organizations to fully utilize their human capital (Van De Voorde et al., 2012). Happy employees seem to be gregarious, amiable and they contribute more to contextual performance. Positive organizational results are projected to grow in businesses with happy employees and it is also believed that happy employees would take fewer actions that endanger the organization’s success. Generally, employees who are happy at work are less likely to involve in counterproductive work behaviours (A. Singh & Banerji, 2022; Thompson & Bruk-Lee, 2021). Maintaining happy employees may be extremely useful in terms of lowering the attrition rate as a high attrition rate may lead to reduced productivity, high replacement cost, and dysfunctional organizational cultures (Staw, 1980). Hence, EH is necessary to keep business on track.

The Indian retail industry contributes significantly to the country’s economy, making up about 10% of its GDP and providing employment to over 40 million people. It is the fifth-largest retail market globally, and it is expected to reach US \$1.5 trillion by 2030, further emphasizing its importance to the country’s economy (IBEF, 2022). This growth of India’s retail industry has increased the demand for skilled personnel, emphasizing the need for efective HR systems, policies, and practices to meet the industry’s rapidly growing demands (Singh & Mishra, 2008).

HR plays a vital role in retail, as employees who deal with customers are perceived as the face of the organization. Recognizing the importance of HR in the growth and development of India’s retail sector, this study examines the relationship between POS, EH, and OCB. However, research on the link between POS and OCB through EH in the Indian context, under the social exchange theory, is still limited. Therefore, this study aims to empirically explore POS as a predictor of EH and OCB to address this gap.

## Literature Review

## Perceived Organizational Support

POS is described as employees—“global beliefs about the extent to which the organization cares about their well-being and values their contributions” (Eisenberger et al., 1986). POS includes workplace justice, supervisor’s support, good working conditions, and organizational rewards which ultimately determine how well employees will accomplish their inrole tasks (Rhoades & Eisenberger, 2002). If employees have a propitious view about these factors, it will cultivate a sense of belongingness with the organization. Furthermore, POS stimulates desirable results such as increased dedication, trust, and positive attitude (Yu & Frenkel, 2013). As a result of POS, employees may feel obligated to help the business in achieving its objectives. The employee’s positive perception of management support would result in a social exchange relationship between the company and its employees, inspiring them to act in ways that the company values (Yu & Frenkel, 2013).

## Employee Happiness

Albert Schweitzer opined that “success is not the key to happiness, happiness is the key to success” (Thompson & Bruk-Lee, 2021). Despite this prevalent notion, EH is usually considered as an insubstantial topic by corporate entities, immaterial to the bottom-line results. Many positive organizational outcomes are likely to be derived from happy employees for example job satisfaction, organizational commitment, and lower turnover rate (Thompson & Bruk-Lee, 2021). Happiness is a multifaceted notion that encompasses psychological well-being, positive emotions, and overall satisfaction with work and life (Diener, 2000; Fisher, 2010; Grant et  al., 2007). EH has been influenced by a variety of factors, which can be clubbed into four broad categories i.e., personal factors, factors related to family environment, organizational and social factors (Dutschke et  al., 2019; Espasandín-Bustelo et al., 2020). Past studies have identified social support available at work (Drummond et  al., 2017), leadership style (Perko et  al., 2016), training & development opportunities and resourceful environment (Xanthopoulou et al., 2012) as the organizational factors that linked employee happiness.

## Organizational Citizenship Behaviour

The OCB was initially characterized as “individual behavior that is discretionary, not directly or explicitly recognized by the formal reward system and that in the aggregate promotes the efective functioning of the organization”(Organ, 1988). Employees who believe they are "citizens" of their organizations, willingly adopt initiatives that assist not only their coworkers but the organization as a whole (Grego-Planer, 2019). Workers’ OCBs improve teamwork and aid in promoting organizational productivity (Lin & Peng, 2010). According to Williams and Anderson (1991), OCB can be classified into two major dimensions: Citizenship behaviour towards the individual (OCB-I) and towards organizations (OCB-O). OCB-I is interpreted as ofering support to co-workers related to their assigned tasks and exhibiting empathy while they are experiencing personal problems. To help the organization as a whole, an employee engages in OCB-O. For instance, proving innovative solutions to the issues, adhering to rules & regulations, and contributing to the successful implementation of the strategy. Employees who exemplify these behaviours are treated as valuable assets of organizations and are a source of competitive advantage.

## Theoretical Foundation and Hypotheses Development

The current study examines POS, EH and OCB all within the framework of social exchange theory (SET). SET has been frequently deployed to understand the mutual interactions that have been developed between employees and the organization. According to (Blau, 1964) positive behaviour from others are more likely to be reciprocated by employees. In an organization when an employer treats the workforce fairly, praises their eforts, and genuinely is concerned about their well-being, employees feel a deep sense of gratitude and thus, strongly encourage to reciprocate (Dawley et al., 2008). To repay their organizations, employees tend to exhibit positive work attitudes such as higher performance, extrarole behaviours, and increased organizational commitment (Aryee et  al., 2002). Such an ideal scenario can only be achieved when employees at a company abide by the exchange’s norms and regulations (Cropanzano & Mitchell, 2005). SET claims that a healthy relationship between employees and managers/ supervisor fosters a mutual understanding that creates a collaborative work environment that would be advantageous for both employees and the organizations (Cole et al., 2002). Applying SET, this research synthesizes the literature on perceived organizational support, employee happiness, and organizational support to formulate the following  hypotheses. The conceptual model for this research is shown in Fig. 1.

## Perceived Organizational Support and Employee Happiness

Past studies have repeatedly highlighted the benefits of having an employee that feels supported by organizations (Gaëtane Baran et al., 2012; Caesens et al., 2017; Kurtessis et al., 2015). Particularly, POS was found to be strongly related to diferent desirable employment outcomes namely, work engagement, loyalty, & employees’ subjective well-being and negatively associated with inimical work behaviour such as intention to quit (Eisenberger & Stinglhamber, 2011). It is believed that POS satisfies a number of socioemotional needs such as esteem need, emotional support, need for afiliation, etc. which in turn improves employees’ well-being (Kurtessis et  al., 2015). Happiness or well-being at work is crucial for fostering employees’ optimal performance and minimizing absenteeism, and poor physical & mental health (Panaccio & Vandenberghe, 2009). Additionally, it has been determined that POS is associated with reduced levels of psychological stress among workers, higher job satisfaction & happiness, and favourable attitudes toward their organization (Caesens & Stinglhamber, 2014; Panaccio & Vandenberghe, 2009).

![](images/cc214d13c90ddab53749201c97df38db21b5066d956cc6bfc2395f87325704d0.jpg)  
Fig. 1 Conceptual model

So, we propose the hypothesis as:

${ \bf { H 1 } } _ { \bf { i } } \colon \quad $ There is a positive relationship between POS and EH.

## Perceived Organizational Support and Organizational Citizenship Behaviour

According to the SET, when employees feel that the organization values their contributions whether through inclusion in the elite workforce or in a diferent way, they will reciprocate by acting favourably in several ways viz. employee engagement, commitment, and organizational citizenship behaviour (Wayne et al., 2002). This theory also contended that if employees feel highly supported by their organizations, they produce a higher degree of OCB by building psychological capital. Bartkowiak et  al. (2020) found that workers often have greater OCB, job stability, and subjective well-being when they perceive that top managers and organizations are supportive. Similarly, prior research demonstrated a significant positive connection between POS and OCB (Kaufman et al., 2001; Piercy et al., 2006). Hence, the hypothesis is proposed as:

$\mathbf { H 1 } _ { 2 } \colon$ There is a positive relationship between POS and OCB.

## Employee Happiness and Organizational Citizenship Behaviour

Happiness is seen to have a beneficial impact on workers and  triggers positive behavioural changes (Lyubomirsky et al., 2005). Happy workers are found to be more altruistic, empathic, and visibly have greater OCB (Avey et  al., 2008; Barsade & Gibsonk, 2007; Spector & Fox, 2002). Happiness or Positive emotions promote deeper connections, relationship development, social integration, and the formation of more efective social interactions (Diener & Seligman, 2002; Waugh & Fredrickson, 2006) which may lead to the courteous, compassionate, and sympathetic behaviour of employees (Rego et  al., 2010). Happy employees are always inclined to assist their organization regardless of their formal roles and responsibilities (George, 1991). In the same vein, Williams and Shiaw (1999) suggested that positive emotions at work encourage extra-role behaviour (OCB), which benefits organizations and improves organizational results. So, we propose the hypothesis as:

$\mathbf { H 1 } _ { 3 } \colon$ : There is a positive relationship between EH and OCB.

## Employee Happiness as a Mediator Between Perceived Organizational Support and Organizational Citizenship Behaviour

Happiness at work has a substantial and profound impact on the employees’ productivity, quality of life and job satisfaction (Bhattacharjee & Bhattcharjee, 2010; Boehm & Lyubomirsky, 2008; Marescaux et al., 2019). According to George (1991) employees who perceive afective well-being at work, engage in more prosocial conduct. Happy employees are more inclined to have favourable opinions of their workplace and coworkers, which promotes additional role engagement (S. Williams & Shiaw, 1999). POS has been identified as one of the predictors of employee happiness. POS amplifies the feeling of positivity among employees by strengthening their perceptions that the company values their work and performance (Rhoades & Eisenberger, 2002). POS ensures that assistance will be provided by the employer as needed to efectively perform one’s task and handle challenging circumstances, which promotes the psychological well-being of employees. SET can also be used to comprehend the mediating role of employee happiness in the link between POS and OCB. According to SET, in a work environment where employees feel supported by their organization, they experience better sentiments and moods, resulting in higher levels of happiness, which may lead to organizational citizenship behaviour.

As a result, it is hypothesized that:

${ \bf { H 1 } } _ { 4 } { \bf { : } }$ EH mediates the relationship between POS and OCB.

## Research Methodology

A standardized questionnaire was used to gather the data from small and medium retail sector employees working in Gorakhpur City (Uttar Pradesh, India). Gorakhpur city of eastern Uttar Pradesh, India, is known for its rich cultural and historical significance and it has become a thriving commercial and trading center. With a population of 673,448 people in 2011, it was designated as a metropolis area in 2021 (Wikipedia, 2023). The city ofers a vast and lucrative consumer base for the retail industry, with several shopping malls and standalone stores ofering local and international brands in various categories. Its proximity to major industrial and commercial hubs makes it an advantageous location for setting up a retail business.

A convenience sampling method was adopted to distribute 350 survey forms to employees who were either full or part-time employed in supermarkets, departmental stores and shopping malls. A total of 247 responses were received out of which 219 were found to be valid (duly filled). Table 1 depicts the respondents’ demographic characteristics.

## Measures

The survey instrument was designed utilizing scales that had already been validated from prior research. It was divided into two sections: (1) participants demographic details and (2) measures of the current study factors. A nominal scale was used to assess demographic factors whereas POS, EH, and OCB were measured on a Likert 5-point scale, that ranges from strongly disagree (1) to strongly agree (5). Table 2 depicts the details of Study’s measures.

Table1General characteristics of respondents (N=219)
<table><tr><td>No</td><td>Demographics</td><td>Categories</td><td>Frequency</td><td>Percentage</td></tr><tr><td>1</td><td>Gender</td><td>Male</td><td>162</td><td>74.0</td></tr><tr><td></td><td></td><td>Female</td><td>57</td><td>26.0</td></tr><tr><td>2</td><td>Age</td><td>18-29</td><td>30</td><td>13.7</td></tr><tr><td></td><td></td><td>30-40</td><td>62</td><td>28.3</td></tr><tr><td></td><td></td><td>41-50</td><td>56</td><td>25.6</td></tr><tr><td></td><td></td><td>Above 50 years</td><td>71</td><td>32.4</td></tr><tr><td>3</td><td>Education</td><td>High school</td><td>30</td><td>13.7</td></tr><tr><td></td><td></td><td>Diploma</td><td>44</td><td>20.1</td></tr><tr><td></td><td></td><td>Intermediate</td><td>53</td><td>24.2</td></tr><tr><td></td><td></td><td>Bachelor&#x27;s degree</td><td>79</td><td>36.1</td></tr><tr><td></td><td></td><td>Postgraduate degree</td><td>13</td><td>5.9</td></tr><tr><td>4</td><td>Marital status</td><td>Married</td><td>136</td><td>62.1</td></tr><tr><td></td><td></td><td>Unmarried</td><td>83</td><td>37.9</td></tr><tr><td>5</td><td>Income (Monthly)</td><td>Less than 20000</td><td>98</td><td>44.7</td></tr><tr><td></td><td></td><td>20000-40000</td><td>77</td><td>35.2</td></tr><tr><td></td><td></td><td>40001-60000</td><td>18</td><td>8.2</td></tr><tr><td></td><td></td><td>Above 60000</td><td>26</td><td>11.9</td></tr><tr><td>6</td><td>Position</td><td>Employee</td><td>122</td><td>55.7</td></tr><tr><td></td><td></td><td>Supervisor</td><td>65</td><td>29.7</td></tr><tr><td></td><td></td><td>Manager</td><td>32</td><td>14.6</td></tr><tr><td>7</td><td>Experience</td><td>Below 5 years</td><td>68</td><td>31.0</td></tr><tr><td></td><td></td><td>5–10 years</td><td>100</td><td>45.7</td></tr><tr><td></td><td></td><td>11 years and above</td><td>51</td><td>23.3</td></tr></table>

Table 2 Study’s measures
<table><tr><td>Construct</td><td>Number of items</td><td>Source</td></tr><tr><td>POS</td><td>8</td><td>(Eisenberger et al., 1986)</td></tr><tr><td>EH</td><td>8</td><td>(Hills &amp; Argyle, 2002)</td></tr><tr><td>OCB</td><td>7</td><td>(Van Dyne &amp; LePine, 1998)</td></tr></table>

## Data Analysis

A two-step approach was employed for data analysis. Firstly, confirmatory factor analysis (CFA) was applied to verify the measurement scale’s validity and reliability. Furthermore, the direct and mediation hypotheses were tested using the SEM with AMOS 26.

## Measurement Model

The findings in Table 3 show that the average variance extracted (AVE) for all factors are more than the threshold value of 0.50 and the composite reliability (CR) value is more than 0.7, exhibiting the measurement scale’s convergent validity (Hair et al., 2017). Additionally, as indicated in Table 4, the AVE value for each variable is higher than any correlation coeficient, supporting the discriminant validity of the constructs. (Fornell & Larcker, 1981). Cronbach’s alpha values for each research construct are greater than 0.6, showing that each construct has the necessary reliability (Sekaran & Bougie, 2016). The measurement model of this study is exhibited in Fig. 2

Table 3 Summary of the measurement model
<table><tr><td>Variables and items</td><td>Factor loading</td><td>Alpha</td><td>AVE</td><td>CR</td></tr><tr><td>Perceived organizational support</td><td></td><td>.965</td><td>0.783</td><td>0.966</td></tr><tr><td>POS 1</td><td>.901</td><td></td><td></td><td></td></tr><tr><td>POS 2</td><td>.851</td><td></td><td></td><td></td></tr><tr><td>POS 3</td><td>.892</td><td></td><td></td><td></td></tr><tr><td>POS 4</td><td>.936</td><td></td><td></td><td></td></tr><tr><td>POS 5</td><td>.893</td><td></td><td></td><td></td></tr><tr><td>POS 6</td><td>.930</td><td></td><td></td><td></td></tr><tr><td>POS 7</td><td>.897</td><td></td><td></td><td></td></tr><tr><td>POS 8</td><td>.768</td><td></td><td></td><td></td></tr><tr><td>Employee happiness</td><td></td><td>.944</td><td>.737</td><td>.943</td></tr><tr><td>EH 1</td><td>.814</td><td></td><td></td><td></td></tr><tr><td>EH 2</td><td>.868</td><td></td><td></td><td></td></tr><tr><td>EH3</td><td>.864</td><td></td><td></td><td></td></tr><tr><td>EH4</td><td>.849</td><td></td><td></td><td></td></tr><tr><td>EH 5</td><td>.901</td><td></td><td></td><td></td></tr><tr><td>EH 6</td><td>.853</td><td></td><td></td><td></td></tr><tr><td>Organizational citizenship behaviour</td><td></td><td>.965</td><td>.801</td><td>.965</td></tr><tr><td>OCB 1</td><td>.897</td><td></td><td></td><td></td></tr><tr><td>OCB 2</td><td>.918</td><td></td><td></td><td></td></tr><tr><td>OCB 3</td><td>.938</td><td></td><td></td><td></td></tr><tr><td>OCB 4</td><td>.912</td><td></td><td></td><td></td></tr><tr><td>OCB 5</td><td>.882</td><td></td><td></td><td></td></tr><tr><td>OCB 6</td><td>.902</td><td></td><td></td><td></td></tr><tr><td>OCB 7</td><td>.812</td><td></td><td></td><td></td></tr><tr><td>Table 4 Discriminant validity</td><td>Constructs</td><td>POS</td><td>EH</td><td>OCB</td></tr><tr><td></td><td>POS</td><td>0.884</td><td></td><td></td></tr><tr><td></td><td>EH</td><td>0.633</td><td>0.858</td><td></td></tr><tr><td></td><td>OCB</td><td>0.519</td><td>0.463</td><td>0.894</td></tr></table>

Discriminant validity is depicted diagonally and is in bold

![](images/e2bc7c9c7f94a70e6b838d020f540774b5debc7eedd103fe948d8e8abd53e69d.jpg)  
Fig. 2 Measurement model

Table 5 Model fit statistics
<table><tr><td>Fit indices</td><td>Obtained value</td><td>Cut-off value</td><td>Reference</td></tr><tr><td> $x ^ { 2 } / \mathrm { d f }$ </td><td>2.32</td><td>&lt;5</td><td>(Hooper et al., 2008; Hu &amp; Bentler, 1999)</td></tr><tr><td>SRMR</td><td>.057</td><td>≤0.06</td><td></td></tr><tr><td>RMSEA</td><td>.08</td><td>≤0.08</td><td></td></tr><tr><td>CFI</td><td>.95</td><td>&gt;0.9</td><td></td></tr><tr><td>NFI</td><td>.92</td><td>&gt;0.9</td><td></td></tr><tr><td>TLI</td><td>.94</td><td>&gt;0.9</td><td></td></tr><tr><td>AGFI</td><td>.81</td><td>&gt;0.8</td><td></td></tr></table>

## Model Fit

According to Hair et al. (2010), it is crucial to examine the goodness of fit indices of the model before making any conclusions. The $x ^ { 2 } / \mathrm { d f } .$ TLI, CFI, NFI, SRMR, and RMSEA are some of the popular indices used to assess the model’s fit. The SEM results shown in Table 5 demonstrate a good model fit.

## Structural model

The structural model reveals  the relationship among  the several research variables both directly and indirectly. Four steps mediation process suggested by Baron and Kenny was utilized to examine the significance of both direct and indirect paths.

Barron and Kenny test for mediation analysis

Condition 1 There must be a considerable impact of the independent variable (IV) on the mediator.

As per condition 1, the impact of POS on EH was examined. Table  6 depicts that p-value $( ^ { * * * } ) < . 0 1$ , demonstrating that POS has a significant impact on EH. Here, $p ^ { * * * }$ indicates that the p-value is .000.The first condition of mediation analysis was met by this. The path model for mediation analysis condition 1 is shown in Fig. 3.

Condition 2 The independent variable (IV) must have a considerable impact on the dependent variable (DV) without the mediator.

In accordance with condition 2, the impact of POS (IV) on OCB (DV) was examined. Table 7 exhibits that the POS has an impact on OCB as the p-value is 0.000 which is less than 0.01. Hence, at the.01 level, the relationship between POS and EH is significant. This met the second requirement of mediation analysis. The path model for the second condition of the mediation analysis is shown in Fig. 4.

Table 6 Standardised regression estimate: POS → EH
<table><tr><td>Direct path</td><td>Beta</td><td>S.E</td><td>C.R</td><td>P</td><td>Result</td></tr><tr><td>POS-EH</td><td>0.510</td><td>0.053</td><td>9.505</td><td>0.000</td><td>Significant</td></tr></table>

![](images/2a9577e6f7f8422bbe328ccb2d278f4bbed6171ee5127248963e245b5a49f8a1.jpg)  
Fig. 3 The path model of POS and EH

Condition 3 The mediator must have a considerable impact on DV.

According to condition 3, the impact of EH on OCB was investigated. Table 8 reveals that the OCB is significantly impacted by the EH (Beta = 0.542, p < 0.01).This fulfilled the third prerequisite for mediation analysis. The path model of mediation analysis for condition 3 is demonstrated in Fig. 5.

Condition 4 Mediation results after introducing the mediator in the model.

The influence of IV on DV becomes less significant after introducing the mediator in the model, then it is called partial mediation. Whereas, full mediation occurs when the impact of IV on DV becomes insignificant if the mediator is included in the model. Table 9 reveals that the p-value for the indirect path is .015<.05. A bootstrapping technique with 5000 resamples was utilized to investigate the indirect efect. Figure 6 indicates that EH partially mediates the relationship between POS and OCB. Partial mediation exists because the standardized regression weight between POS and OCB reduced from 0.49 to 0.35 after including EH. The path model of mediation analysis for condition 4 is demonstrated in Fig. 6.

Table 7 Standardised regression estimate: POS → OCB
<table><tr><td>Direct path</td><td>Beta</td><td>S.E</td><td>C.R</td><td>P</td><td>Result</td></tr><tr><td>POS—OCB</td><td>.49</td><td>.061</td><td>8.032</td><td>.000</td><td>Significant</td></tr></table>

![](images/0b34cc9e882b7946bd9c41352e2f150e871b758fb2e57a9ad8a9754bb6730940.jpg)  
Fig. 4 The path model of POS and OCB

The results of path analysis show that POS has a positive relationship with EH $( \mathrm { b } { = } 0 . 5 1 0 ,$ ${ p { < } 0 . 0 0 1 ) }$ and OCB $( \mathbf { b } { = } 0 . 4 9 , p { < } 0 . 0 0 1$ . In a similar vein, EH significantly and positively influences OCB. $\scriptstyle ( \mathsf { b } = 0 . 5 4 2$ ${ p < 0 . 0 0 1 } $ ).Consequently, $\operatorname { H 1 } _ { 1 } , \operatorname { H 1 } _ { 2 } ,$ and $\mathrm { H } 1 _ { 3 }$ are supported. Furthermore, the result reveals that EH partially mediates the relationship between POS and OCB $( { \mathrm { b } } { = } 0 . 1 4 ,$ $p { < } 0 . 0 5 )$ . Hence, $\mathrm { H } 1 _ { 4 }$ is proven.

## Discussion

The goal of this research work was to ascertain the efect of POS on extra role performances. Additionally, this research aimed to identify the efect of EH on this interaction. Consistent with SET, the study’s findings highlighted that POS positively influences OCB confirming the outcomes of earlier studies (Alshaabani et al., 2021; Kaufman et al., 2001; Piercy et al., 2006). Personnel who perceive high POS levels feel obligated to reciprocate the company for its favours by going above and beyond their job roles. However, this outcome contradicts earlier research that was unable to establish any significant direct relationship between POS and OCB (Jehanzeb, 2020). Based on SET, Cropanzano and Mitchell, (2005) stated that employees are expected to conform to the norms of reciprocity, which means that if they perceive that their organization is treating them well, they will be motivated to exhibit positive behaviors. Thus, in consistency with SET, the finding of this research work state that POS creates a positive exchange between employees and organizations leading to increased OCB (Chiaburu et  al., 2015). When employees perceive that the organizations prioritizes their well-being, employees are more likely to involve in discretionary behaviors that benefit the organization. This exchange promotes a positive work environment, reinforces trust, and encourages sustained positive behaviors, ultimately facilitating OCB and contributing to a collaborative work culture and heightened productivity.

Table 8 Standardised regression estimate: EH → OCB
<table><tr><td>Direct path</td><td>Beta</td><td>S.E</td><td>C.R</td><td>P</td><td>Result</td></tr><tr><td>EH- OCB</td><td>.542</td><td>.081</td><td>6.729</td><td>.000</td><td>Significant</td></tr></table>

![](images/35f93b2e60da2d296a97ac66125f6b33307cc09ae81185a3811108654e020be5.jpg)  
Fig. 5 The path model of EH and OCB

Further, the findings revealed that EH is significantly influenced by POS. It is asserted that POS fulfills a range of employees’ socio-emotional needs, which enhances their wellbeing at the workplace. This result aligns with prior research by Caesens et  al. (2017), which stated that employees who perceive greater support and concern from their employer experience improved subjective well-being. The results of this research also revealed that EH is significantly positively associated with OCB. It implies that happy employees are more likely to exhibit OCB. The outcome of the present study is consistent with earlier research that demonstrated a direct link between employee happiness and OCB (George, 1991; Williams & Shiaw, 1999). Happy employees are emotionally connected with their organization and they are more eager to voluntarily contribute in the best interests of the organization. EH raises the propensity to assist other co-workers and to be more cordial, caring, and sympathetic. Moreover, the outcomes of the study reveal that the relationship between POS and OCB is mediated by EH to some extent. It signifies that POS afects OCB not only directly but also indirectly through EH, the justification of this relationship is explored on the basis of SET. When an organization supports its employees by recognizing, rewarding, praising, and motivating them for their hard work and performance the employees have a more positive attitude and behaviour which raises their happiness level and inspire them for OCB for the growth and prosperity of the organization.

Table 9 Standardised regression estimate of total, direct and indirect path
<table><tr><td>Effect</td><td>Standardized P-value estimation</td><td></td><td>Result</td><td>Mediation</td></tr><tr><td>Total effect</td><td>0.49</td><td>.000</td><td>Significant</td><td></td></tr><tr><td>Direct effect</td><td>0.35</td><td>.000</td><td>Significant</td><td></td></tr><tr><td>Indirect effect</td><td>0.14</td><td>.015</td><td>Significant</td><td>Partial</td></tr><tr><td></td><td></td><td></td><td></td><td>Mediation</td></tr></table>

![](images/d533bb2884d4ee7fb2261c15268b5986cd4d169d65c2418b8085a191ad3241ee.jpg)  
Fig. 6 The mediation path

POS has the potential to induce felt obligations. POS improves organization efectiveness by cultivating employees’ feelings of obligation and elevating reciprocity norms between employees and the organization. Hence, organizations must invest in the workforce to improve their feeling of support. In summary, our study supports the hypothesis that POS is crucial in promoting EH at work, which in turn causes OCB.

## Managerial Implication

The study’s outcomes have practical implications for the organizations as they are understanding the benefits they can reap by providing support to workers. The findings of this study show that to achieve better OCB, firms should concentrate on fostering happiness at work. This can be done by ofering increased organizational support, which is considered as a major antecedent of EH and OCB. Organizations must ensure that they provide appropriate working conditions, wellness programs, flexible work arrangements, health care, and safety measures for their employees. Organizations are also recommended to respect employees’ viewpoints and eforts and assist them in developing their skills and capabilities for promoting the happiness of employees and maximizing extra-role performance. Furthermore, managers should  formulate  and implement POS-oriented human resource policies. The likelihood that employees will exhibit OCB increases with the extent of assistance they receive from their employers. The employees’ extra-role behaviour will contribute to the eficient operation of an organization.

## Conclusion

Despite the growing interest in POS, EH and OCB in today’s highly volatile and competitive environment, only a few research have looked at the interaction between POS and OCB in the presence of EH as a mediator in the Indian context. Overall, the research’s findings indicate that POS decreases employees’ perceptions of being regarded as the only means for achieving the objectives of the organization by meeting their physiological, social, and esteem needs. POS make employees aware that they are valued, recognized, and accepted as a member of organizations which triggers increased levels of happiness among employees. Happy employees are more inclined to indulge in extra-role performance. SET also posits that positive social exchange relationships result in increased loyalty and OCB towards their organizations.

## Future Research Directions

Although the current research has its merits, it also has certain limitations that need to be acknowledged and taken up in future research work. Firstly, researchers should gather data from diferent locations and industries to enhance the generalizability of the study’s results. This would give us a better idea of whether the relationships observed in the study are consistent across diferent contexts. Additionally, researchers can investigate how demographic factors, such as gender, experience, and age, might afect the link between POS and OCB. By studying these variables, researchers could gain a better understanding of how diferent groups of employees perceive and respond to POS and how this afects their willingness to engage in OCB. Finally, future research could explore other factors beyond EH that could impact the relationship between POS and OCB, such as organizational trust, psychological capital, and organizational commitment. By examining these factors more closely, researchers can gain a more complete understanding of what drives OCB and identify other ways to encourage OCB in the workplace.

Data Availability Data used in this research paper are available from the authors.

## Declarations

Conflict of Interest The authors declare that they have no competing interests.

## References

Alshaabani, A., Naz, F., Magda, R., & Rudnák, I. (2021). Impact of perceived organizational support on OCB in the time of covid-19 pandemic in hungary: Employee engagement and afective commitment as mediators. Sustainability, 13(14). https://doi.org/10.3390/su13147800

Aryee, S., Budhwar, P. S., & Chen, Z. X. (2002). Trust as a mediator of the relationship between organizational justice and work outcomes: Test of a social exchange model. Journal of Organizational Behav ior, 23(3), 267–285. https://doi.org/10.1002/job.138

Avey, J. B., Wernsing, T. S., & Luthans, F. (2008). Can positive employees help positive organizational change?: Impact of psychological capital and emotions on relevant attitudes and behaviors. Journal of Applied Behavioral Science, 44(1), 48–70. https://doi.org/10.1177/0021886307311470

Baran, B. E., Shanock, L. R., & Miller, L. R. (2012). Advancing organizational support theory into the twenty-first century world of work. Journal of Business and Psychology, 27(2), 123–147. https://doi. org/10.1007/s10869-011-9236-3

Barsade, S. G., & Gibsonk, D. E. (2007). Why does afect matter in organizations? Academy of Management Perspectives, 21(1), 36–59. https://doi.org/10.5465/amp.2007.24286163

Bartkowiak, G., Krugiełka, A., Dachowski, R., Gałek, K., & Kostrzewa-Demczuk, P. (2020). Attitudes of Polish entrepreneurs towards 65+ knowledge workers in the context of their pro-social attitude and organizational citizenship behavior. Sustainability, 12(13), 5294. https://doi.org/10.3390/su12135294

Bhattacharjee, D., & Bhattcharjee, M. (2010). Measuring happiness at work place. ASBM Journal of Management, 3(1/2), 112.

Blau, P. M. (1964). Exchange and power in social life. Wiley.

Boehm, J. K., & Lyubomirsky, S. (2008). Does happiness promote career success? Journal of Career Assessment, 16(1), 101–116. https://doi.org/10.1177/1069072707308140

Caesens, G., & Stinglhamber, F. (2014). The relationship between perceived organizational support and work engagement: The role of self-eficacy and its outcomes. Revue Europeenne De Psychologie Appliquee, 64(5), 259–267. https://doi.org/10.1016/j.erap.2014.08.002

Caesens, G., Stinglhamber, F., Demoulin, S., & De Wilde, M. (2017). Perceived organizational support and employees’ well-being: The mediating role of organizational dehumanization. European Journal of Work and Organizational Psychology, 26(4), 527–540. https://doi.org/10.1080/1359432X.2017.1319817

Chiaburu, D. S., Chakrabarty, S., Wang, J., & Li, N. (2015). Organizational support and citizenship behaviors: A comparative cross-cultural meta-analysis. Management International Review, 55(5), 707–736. https://doi.org/10.1007/s11575-015-0253-8

Cole, M. S., Schaninger, W. S., & Harris, S. G. (2002). The workplace social exchange network: A multilevel conceptual examination. Group & Organization Management, 27(1), 142–167. https://doi.org/10. 1177/1059601102027001008

Cropanzano, R., & Mitchell, M. S. (2005). Social exchange theory: An interdisciplinary review. Journal of Management, 31(6), 874–900. https://doi.org/10.1177/0149206305279602

Dawley, D. D., Andrews, M. C., & Bucklew, N. S. (2008). Mentoring, supervisor support, and perceived organizational support: What matters most? Leadership and Organization Development Journal, 29(3), 235–247. https://doi.org/10.1108/01437730810861290

Diener, E. (2000). Subjective well-being: The science of happiness and a proposal for a national index. American Psychologist, 55(1), 34–43. https://doi.org/10.1037/0003-066X.55.1.34

Diener, E., & Seligman, M. E. P. (2002). Very happy people. Psychological Science, 13(1), 81–84. https://doi.org/10.1111/1467-9280.00415

Drummond, S., O’Driscoll, M. P., Brough, P., Kalliath, T., Siu, O. L., Timms, C., & Riley, D. (2017). The relationship of social support with well-being outcomes via work–family conflict: Moderating efects of gender, dependants and nationality. Human Relations, 70(5), 544–565. https://doi.org/10. 1177/0018726716662696

Dutschke, G., Jacobsohn, L., Dias, A., & Combadão, J. (2019). The job design happiness scale (JDHS). Journal of Organizational Change Management, 32(7), 709–724. https://doi.org/10.1108/JOCM-01-2018-0035

Eisenberger, R., Huntington, R., Hutchison, S., & Sowa, D. (1986). Perceived organizational support. Journal of Applied Psychology, 71(3), 500–507. https://doi.org/10.1037/0021-9010.71.3.500

Eisenberger, R., & Stinglhamber, F. (2011). Perceived organizational support: Fostering enthusiastic and productive employees. American Psychological Association. https://doi.org/10.1037/12318-000

Erdogan, B., & Enders, J. (2007). Support from the top: Supervisors’ perceived organizational support as a moderator of leader-member exchange to satisfaction and performance relationships. Journal of Applied Psychology, 92(2), 321–330. https://doi.org/10.1037/0021-9010.92.2.321

Espasandín-Bustelo, F., Ganaza-Vargas, J., & Diaz-Carrion, R. (2020). Employee happiness and corporate social responsibility: The role of organizational culture. Employee Relations: The International Journal. https://doi.org/10.1108/ER-07-2020-0343

Fisher, C. D. (2010). Happiness at work. International Journal of Management Reviews, 12(4), 384–412. https://doi.org/10.1111/j.1468-2370.2009.00270.x

Fornell, C., & Larcker, D. F. (1981). Evaluating structural equation models with unobservable variables and Journal of Marketing Research, 18

George, J. M. (1991). State or trait: Efects of positive mood on prosocial behaviors at work. Journal of Applied Psychology, 76(2), 299–307. https://doi.org/10.1037/0021-9010.76.2.299

Grant, A. M., Christianson, M. K., & Price, R. H. (2007). Happiness, health, or relationships? Managerial practices and employee well-being tradeofs. Academy of Management Perspectives, 21(3), 51–63. https://doi.org/10.5465/AMP.2007.26421238

Grego-Planer, D. (2019). The relationship between organizational commitment and organizational citizenship behaviors in the public and private sectors. Sustainability, 11(22), 1–20. https://doi.org/10. 3390/su11226395

Hair, J. F., Black, W. C., & Barbin, B. J. (2010). Multivariate data analysis: A global perspective. Pearson Education.

Hair, J. F., Sarstedt, M., Ringle, C. M., & Gudergan, S. P. (2017). Advanced issues in partial least squares structural equation modeling. Sage Publications.

Hills, P., & Argyle, M. (2002). The Oxford happiness questionnaire: A compact scale for the measurement of psychological well-being. Personality and Individual Diferences, 33(7), 1073–1082. https://doi.org/10.1016/S0191-8869(01)00213-6

Hooper, D., Coughlan, J., & Mullen, M. R. (2008). Structural equation modelling: Guidelines for determining model fit. Electornic Journal of Business Research Methods, 6(1), 53–60. https://doi.org/ 10.3791/63381

Hu, L. T., & Bentler, P. M. (1999). Cutof criteria for fit indexes in covariance structure analysis: Conventional criteria versus new alternatives. Structural Equation Modeling, 6(1), 1–55. https://doi. org/10.1080/10705519909540118

IBEF. (2022). Retail industry in India: Overview of Retail Sector, Market Size, Growth. IBEF. Retrieved April 11, 2023, from https://www.ibef.org/industry/retail-india

Jehanzeb, K. (2020). Does perceived organizational support and employee development influence organizational citizenship behavior?: Person–organization fit as moderator. European Journal of Training and Development, 44(6–7), 637–657. https://doi.org/10.1108/EJTD-02-2020-0032

Kaufman, J. D., Stamper, C. L., & Tesluk, P. E. (2001). Do supportive organizations make for good corporate citizens ? Journal of Managerial Issues, 13(4), 436–449.

Kurtessis, J. N., Eisenberger, R., Ford, M. T., Bufardi, L. C., Stewart, K. A., & Adis, C. S. (2015). Perceived organizational support: A meta-analytic evaluation of organizational support theory. Journal of Management, 43(6), 1854–1884. https://doi.org/10.1177/0149206315575554

Lin, C. C. T., & Peng, T. K. T. K. (2010). From organizational citizenship behaviour to team performance: The mediation of group cohesion and collective eficacy. Management and Organization Review, 6(1), 55–75. https://doi.org/10.1111/j.1740-8784.2009.00172.x

Lyubomirsky, S., King, L., & Diener, E. (2005). The benefits of frequent positive afect: Does happiness lead to success? Psychological Bulletin, 131(6), 803–855. https://doi.org/10.1037/0033-2909. 131.6.803

Marescaux, E., Winne, S. D., Leuven, K. U., Forrier, A., & Leuven, K. U. (2019). Developmental HRM, employee well-being and performance: The moderating role of developing leadership. European Management Review, 16(2), 317–331.

Organ, D. W. (1988). Organizational citizenship behavior: The good soldier syndrome. Lexington Books/D. C. Heath and Com.

Panaccio, A., & Vandenberghe, C. (2009). Perceived organizational support, organizational commitment and psychological well-being: A longitudinal study. Journal of Vocational Behavior, 75(2), 224– 236. https://doi.org/10.1016/j.jvb.2009.06.002

Perko, K., Kinnunen, U., Tolvanen, A., & Feldt, T. (2016). Investigating occupational well-being and leadership from a person-centred longitudinal approach: Congruence of well-being and perceived leadership. European Journal of Work and Organizational Psychology, 25(1), 105–119. https://doi. org/10.1080/1359432X.2015.1011136

Piercy, N. F., Cravens, D. W., Lane, N., & Vorhies, D. W. (2006). Driving organizational citizenship behaviors and salesperson in-role behavior performance: The role of management control and perceived organizational support. Journal of the Academy of Marketing Science, 34(2), 244–262. https://doi.org/10.1177/0092070305280532

Ranjhan, S., & Mallick, E. (2018). Organizational citizenship behaviour creating competitive advan tage in indian health care industry: The moderating role of HR practices. Global Business Review, 19(5), 1275–1289. https://doi.org/10.1177/0972150918788629

Rego, A., Ribeiro, N., & Cunha, M. P. (2010). Perceptions of organizational virtuousness and happiness as predictors of organizational citizenship behaviors. Journal of Business Ethics, 93(2), 215–235. https://doi.org/10.1007/s10551-009-0197-7

Rhoades, L., & Eisenberger, R. (2002). Perceived organizational support: A review of the literature. Journal of Applied Psychology, 87(4), 698–714. https://doi.org/10.1037/0021-9010.87.4.698

Sekaran, U., & Bougie, R. (2016). Research methods for business A skill building appraoch. Wiley.

Singh, A., & Banerji, R. (2022). Happiness at work, organization citizenship behaviour and workplace diversity: A study on Indian private sector bank employees. Industrial and Commercial Training, 54(3), 460–475. https://doi.org/10.1108/ICT-05-2021-0037/FULL/XML

Singh, B. D., & Mishra, S. (2008). Indian retail sector- HR challenges & measures for improvement. Indian Journal of Industrial Relations, 44(1), 99–111.

Smith, C. A., Organ, D. W., & Near, J. P. (1983). Organizational citizenship behavior: Its nature and antecedents. Journal of Applied Psychology, 68(4), 653–663. https://doi.org/10.1037/0021-9010. 68.4.653

Spector, P. E., & Fox, S. (2002). An emotion-centered model of voluntary work behavior: Some parallels between counterproductive work behavior and organizational citizenship behavior. Human Resource Management Review, 12(2), 263–292. https://doi.org/10.1016/s1053-4822(02)00049-9

Staw, B. M. (1980). The consequences of turnover. Journal of Occupational Behaviour, 1(4), 253–273.

Thompson, A., & Bruk-Lee, V. (2021). Employee happiness: Why we should care. Applied Research in Quality of Life, 16(4), 1419–1437. https://doi.org/10.1007/s11482-019-09807-z

Van De Voorde, K., Paauwe, J., & Van Veldhoven, M. (2012). Employee well-being and the HRM-Organizational performance relationship: A review of quantitative studies. International Journal of Management Reviews, 14(4), 391–407. https://doi.org/10.1111/j.1468-2370.2011.00322.x

Van Dyne, L., & LePine, J. A. (1998). Helping and voice extra-role behaviors: Evidence of construct and predictive validity. Academy of Management Journal, 41(1), 108–119. https://doi.org/10.2307/ 256902

Waugh, C. E., & Fredrickson, B. L. (2006). Nice to know you: Positive emotions, self–other overlap, and complex understanding in the formation of a new relationship. Journal of Positive Psychology, 1(2), 93–106. https://doi.org/10.1080/17439760500510569

Wayne, S. J., Shore, L. M., Bommer, W. H., & Tetrick, L. E. (2002). The role of fair treatment and rewards in perceptions of organizational support and leader-member exchange. Journal of Applied Psychology, 87(3), 590–598. https://doi.org/10.1037/0021-9010.87.3.590

Wikipedia. (2023). Gorakhpur - Wikipedia. Wikipedia. Retrieved April 11, 2023, from https://en.wikipedia. org/wiki/Gorakhpur

Williams, L. J., & Anderson, S. E. (1991). Job satisfaction and organizational commitment as predictors of organizational citizenship and In-Role behaviors. Journal of Management, 17(3), 601–617. https://doi.org/10.1177/014920639101700305

Williams, S., & Shiaw, W. T. (1999). Mood and organizational citizenship behavior: The efects of positive afect on employee organizational citizenship behavior intentions. Journal of Psychology: Interdisciplinary and Applied, 133(6), 656–668. https://doi.org/10.1080/00223989909599771

Xanthopoulou, D., Bakker, A. B., Demerouti, E., & Schaufeli, W. B. (2012). A diary study on the happy worker: How job resources relate to positive emotions and personal resources. European Journal of Work and Organizational Psychology, 21(4), 489–517. https://doi.org/10.1080/1359432X.2011. 584386

Yu, C., & Frenkel, S. J. (2013). Explaining task performance and creativity from perceived organizational support theory: Which mechanisms are more important? Journal of Organizatioanl Behavior, 34(8), 1165–1181. https://doi.org/10.1002/job.1844

Publisher’s Note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional afiliations.

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law.